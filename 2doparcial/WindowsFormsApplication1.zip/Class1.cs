﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    class estudiante
    {
        private string nombre;
        private string apellido;
        private string escuela;

        public estudiante()
        {
            nombre = "";
            apellido = "";
            escuela = "";
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }

        public string Escuela
        {
            get { return escuela; }
            set { escuela = value; }
        }
    }

    class Estudiante
    {
        private string conexion;

        public Estudiante()
        {
            conexion = "Data Source=DESKTOP-813299S\\SQLEXPRESS;Initial Catalog=p1;Integrated Security=True";
        }

        public List<estudiante> ObtenerEstudiantes()
        {
            List<estudiante> listaEstudiantes = new List<estudiante>();

            try
            {
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    string query = "SELECT nombre, apellido, escuela FROM Estudiante";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        estudiante est = new estudiante();
                        est.Nombre = reader["nombre"].ToString();
                        est.Apellido = reader["apellido"].ToString();
                        est.Escuela = reader["escuela"].ToString();
                        listaEstudiantes.Add(est);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener estudiantes: " + ex.Message);
            }

            return listaEstudiantes;
        }

        public bool Guardar(estudiante est)
        {
            bool exito = false;

            try
            {
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    string query = "INSERT INTO Estudiante (nombre, apellido, escuela) VALUES (@nombre, @apellido, @escuela)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@nombre", est.Nombre);
                    cmd.Parameters.AddWithValue("@apellido", est.Apellido);
                    cmd.Parameters.AddWithValue("@escuela", est.Escuela);

                    conn.Open();
                    int filasAfectadas = cmd.ExecuteNonQuery();

                    if (filasAfectadas > 0)
                    {
                        exito = true;
                        Console.WriteLine("Estudiante guardado correctamente.");
                    }
                    else
                    {
                        Console.WriteLine("No se pudo guardar el estudiante.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al guardar estudiante: " + ex.Message);
                // Puedes manejar el error de acuerdo a tus necesidades
            }

            return exito;
        }
    }
}